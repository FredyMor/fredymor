#!/bin/bash
cd "$(dirname "$0")"
curl -sSL -A "Mozilla/5.0" -o "01_Psicologia_clasica/Vygotski_-_Thinking_and_Speech_(Pensamiento_y_lenguaje_1934).pdf" "https://www.marxists.org/archive/vygotsky/works/words/Thinking-and-Speech.pdf" && echo "OK Vygotski_-_Thinking_and_Speech_(Pensamiento_y_lenguaje_1934).pdf"
curl -sSL -A "Mozilla/5.0" -o "01_Psicologia_clasica/Kantor_-_La_ciencia_de_la_psicologia_un_estudio_interconductual_(trad._Julio_Varela).epub" "https://interbehavioral.com/wp-content/uploads/2023/03/La-ciencia-de-la-psicologia.-Un-J.-R.-KantorNoel-W.-Smith.epub" && echo "OK Kantor_-_La_ciencia_de_la_psicologia_un_estudio_interconductual_(trad._Julio_Varela).epub"
curl -sSL -A "Mozilla/5.0" -o "01_Psicologia_clasica/Kantor_-_The_Science_of_Psychology_An_Interbehavioral_Survey.pdf" "https://interbehavioral.com/wp-content/uploads/2024/05/The-Science-of-Psychology.-An-I-J.-R.-KantorNoel-W.-Smith.pdf" && echo "OK Kantor_-_The_Science_of_Psychology_An_Interbehavioral_Survey.pdf"
